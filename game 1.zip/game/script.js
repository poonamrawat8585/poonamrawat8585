const playerHand = document.querySelector('.player-hand');
const computerHand = document.querySelector('.computer-hand');
const resultText = document.querySelector('.result');
const choices = document.querySelectorAll('.choice');
const playerScoreSpan = document.getElementById('player-score');
const computerScoreSpan = document.getElementById('computer-score');

// Sounds
//const shakeSound = document.getElementById('shake-sound');
//const winSound = document.getElementById('win-sound');
//const loseSound = document.getElementById('lose-sound');
//const drawSound = document.getElementById('draw-sound');

let playerScore = 0;
let computerScore = 0;

const moves = {
  rock: '✊',
  paper: '✋',
  scissors: '✌️'
};

choices.forEach(choice => {
  choice.addEventListener('click', () => {
    const playerChoice = choice.dataset.choice;
    const computerChoice = getComputerChoice();

    // Shake animation 
    playerHand.classList.add('animate');
    computerHand.classList.add('animate');
    resultText.textContent = "Shaking... 🤜🤛";
    //shakeSound.play();

    setTimeout(() => {
      playerHand.classList.remove('animate');
      computerHand.classList.remove('animate');

      // Show hands
      playerHand.textContent = moves[playerChoice];
      computerHand.textContent = moves[computerChoice];

      const result = getResult(playerChoice, computerChoice);
      resultText.textContent = result.text;

      // Update score
      if (result.winner === 'player') {
        playerScore++;
        //winSound.play();
      } else if (result.winner === 'computer') {
        computerScore++;
        //loseSound.play();
      } else {
        //drawSound.play();
      }

      playerScoreSpan.textContent = playerScore;
      computerScoreSpan.textContent = computerScore;
    }, 900);
  });
});

function getComputerChoice() {
  const choices = ['rock', 'paper', 'scissors'];
  return choices[Math.floor(Math.random() * choices.length)];
}

function getResult(player, computer) {
  if (player === computer) return { text: "😎 It's a Draw!", winner: 'none' };

  if (
    (player === 'rock' && computer === 'scissors') ||
    (player === 'paper' && computer === 'rock') ||
    (player === 'scissors' && computer === 'paper')
  ) {
    return { text: "🎉 You Win!", winner: 'player' };
  } else {
    return { text: "💻 Computer Wins!", winner: 'computer' };
  }
}
