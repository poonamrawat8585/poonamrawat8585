document.addEventListener('DOMContentLoaded', () => {
    // --- Gallery Pagination Logic ---
    const galleryGrid = document.querySelector('.gallery-grid');
    const galleryItems = galleryGrid ? galleryGrid.querySelectorAll('.gallery-item') : [];
    
    // Pagination elements
    const currentPageSpan = document.querySelector('.current-page');
    const totalPagesSpan = document.querySelector('.total-pages');
    const prevButton = document.querySelector('.nav-button:first-of-type');
    const nextButton = document.querySelector('.nav-button:last-of-type');

    // Configuration for 5 slides of 10 images
    const ITEMS_PER_SLIDE = 10;     
    const REQUESTED_TOTAL_SLIDES = 5; 
    
    // Calculates how many slides are actually needed for the content
    const MAX_ACTIVE_SLIDES = Math.min(REQUESTED_TOTAL_SLIDES, Math.ceil(galleryItems.length / ITEMS_PER_SLIDE));

    let currentPage = 1;


    function updateGallery() {
        // Calculate the starting and ending index for the current slide
        const start = (currentPage - 1) * ITEMS_PER_SLIDE;
        const end = currentPage * ITEMS_PER_SLIDE;

        // 1. Hide all images
        galleryItems.forEach(item => {
            item.style.display = 'none';
        });

        // 2. Show only the images for the current slide
        for (let i = start; i < end && i < galleryItems.length; i++) {
            galleryItems[i].style.display = 'block';
        }

        // 3. Update pagination text
        if (currentPageSpan) {
            currentPageSpan.textContent = String(currentPage).padStart(2, '0');
        }
        if (totalPagesSpan) {
            totalPagesSpan.textContent = String(REQUESTED_TOTAL_SLIDES).padStart(2, '0');
        }

        // 4. Update navigation button states
        if (prevButton) {
            prevButton.disabled = (currentPage === 1);
            prevButton.style.opacity = (currentPage === 1) ? 0.5 : 1;
        }
        if (nextButton) {
            nextButton.disabled = (currentPage >= MAX_ACTIVE_SLIDES); 
            nextButton.style.opacity = (currentPage >= MAX_ACTIVE_SLIDES) ? 0.5 : 1;
        }
    }

    function goToNextSlide() {
        if (currentPage < MAX_ACTIVE_SLIDES) {
            currentPage++;
            updateGallery();
        }
    }

    function goToPrevSlide() {
        if (currentPage > 1) {
            currentPage--;
            updateGallery();
        }
    }

    // --- Event Listeners ---
    if (nextButton) {
        nextButton.addEventListener('click', goToNextSlide);
    }
    if (prevButton) {
        prevButton.addEventListener('click', goToPrevSlide);
    }

    // Initial load: display the first slide when the page loads
    if (galleryItems.length > 0) {
        updateGallery();
    }


    // --- Mobile Menu Toggle Logic ---
    const mobileMenuButton = document.getElementById('mobile-menu-toggle');
    const mainNav = document.getElementById('main-nav');
    
    if (mobileMenuButton && mainNav) {
        mobileMenuButton.addEventListener('click', () => {
            mainNav.classList.toggle('nav--open');
        });

        const navLinks = mainNav.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (mainNav.classList.contains('nav--open')) {
                    setTimeout(() => {
                        mainNav.classList.remove('nav--open');
                    }, 50); 
                }
            });
        });
    }

});