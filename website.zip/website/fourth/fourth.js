document.addEventListener('DOMContentLoaded', () => {

    // --- Configuration Constants ---
    const ITEMS_PER_SLIDE = 3;     // The number of certificates to display on each slide
    const REQUESTED_TOTAL_SLIDES = 5; // The total number of pages to show in the display (05)

    // --- DOM Elements for Certificates and Pagination ---
    const certificatesGrid = document.querySelector('.certificates-grid');
    const certificateItems = certificatesGrid ? certificatesGrid.querySelectorAll('.certificate-item') : [];
    
    const currentPageSpan = document.querySelector('.current-page');
    const totalPagesSpan = document.querySelector('.total-pages');
    const prevButton = document.querySelector('.pagination .nav-button:first-of-type'); // Assuming the first button is '-'
    const nextButton = document.querySelector('.pagination .nav-button:last-of-type');  // Assuming the last button is '->'

    // Calculate the maximum number of slides that actually contain content (based on the number of items)
    const MAX_ACTIVE_SLIDES = Math.min(
        REQUESTED_TOTAL_SLIDES, 
        Math.ceil(certificateItems.length / ITEMS_PER_SLIDE)
    );

    let currentPage = 1;

    /**
     * Updates the displayed certificates, pagination text, and navigation button states.
     */
    function updateCertificates() {
        const start = (currentPage - 1) * ITEMS_PER_SLIDE;
        const end = currentPage * ITEMS_PER_SLIDE;

        // 1. Hide all certificate items
        certificateItems.forEach(item => {
            item.style.display = 'none';
        });

        // 2. Show only the items for the current slide
        for (let i = start; i < end && i < certificateItems.length; i++) {
            // Display as a block element since the CSS grid handles the horizontal layout
            certificateItems[i].style.display = 'block'; 
        }

        // 3. Update pagination text
        if (currentPageSpan) {
            currentPageSpan.textContent = String(currentPage).padStart(2, '0');
        }
        if (totalPagesSpan) {
            // Display the REQUESTED total slides (05)
            totalPagesSpan.textContent = String(REQUESTED_TOTAL_SLIDES).padStart(2, '0');
        }

        // 4. Update navigation button states
        if (prevButton) {
            prevButton.disabled = (currentPage === 1);
            prevButton.style.opacity = (currentPage === 1) ? 0.5 : 1;
        }
        if (nextButton) {
            // Disable when the current page equals the maximum content slide
            nextButton.disabled = (currentPage >= MAX_ACTIVE_SLIDES); 
            nextButton.style.opacity = (currentPage >= MAX_ACTIVE_SLIDES) ? 0.5 : 1;
        }
    }

    /**
     * Navigates to the next slide.
     */
    function goToNextSlide() {
        if (currentPage < MAX_ACTIVE_SLIDES) {
            currentPage++;
            updateCertificates();
        }
    }

    /**
     * Navigates to the previous slide.
     */
    function goToPrevSlide() {
        if (currentPage > 1) {
            currentPage--;
            updateCertificates();
        }
    }

    // --- Event Listeners for Pagination ---
    if (nextButton) {
        nextButton.addEventListener('click', goToNextSlide);
    }
    if (prevButton) {
        prevButton.addEventListener('click', goToPrevSlide);
    }

    // Initial load: display the first slide
    if (certificateItems.length > 0) {
        updateCertificates();
    }


    // --- Mobile Menu Toggle Logic (Replicated for this page) ---
    const mobileMenuButton = document.getElementById('mobile-menu-toggle');
    const mainNav = document.getElementById('main-nav');
    
    if (mobileMenuButton && mainNav) {
        mobileMenuButton.addEventListener('click', () => {
            mainNav.classList.toggle('nav--open');
        });

        const navLinks = mainNav.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (mainNav.classList.contains('nav--open')) {
                    setTimeout(() => {
                        mainNav.classList.remove('nav--open');
                    }, 50); 
                }
            });
        });
    }

});