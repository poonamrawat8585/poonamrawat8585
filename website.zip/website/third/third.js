document.addEventListener('DOMContentLoaded', () => {

    // --- Configuration Constants ---
    const ITEMS_PER_SLIDE = 3;     // The number of projects to display on each slide
    const REQUESTED_TOTAL_SLIDES = 5; // The total number of pages to show in the display (e.g., 05)

    // --- DOM Elements for Projects and Pagination ---
    const projectsList = document.querySelector('.projects-list');
    const projectItems = projectsList ? projectsList.querySelectorAll('.project-list-item') : [];
    
    const currentPageSpan = document.querySelector('.current-page');
    const totalPagesSpan = document.querySelector('.total-pages');
    const prevButton = document.querySelector('.pagination .prev-button'); // Uses class added in HTML update
    const nextButton = document.querySelector('.pagination .next-button'); // Uses class added in HTML update

    // Calculate the maximum number of slides that actually contain content (based on 15 total items)
    const MAX_ACTIVE_SLIDES = Math.min(
        REQUESTED_TOTAL_SLIDES, 
        Math.ceil(projectItems.length / ITEMS_PER_SLIDE)
    );

    let currentPage = 1;

    /**
     * Updates the displayed projects, pagination text, and navigation button states.
     */
    function updateProjects() {
        const start = (currentPage - 1) * ITEMS_PER_SLIDE;
        const end = currentPage * ITEMS_PER_SLIDE;

        // 1. Hide all project items
        projectItems.forEach(item => {
            item.style.display = 'none';
        });

        // 2. Show only the items for the current slide
        for (let i = start; i < end && i < projectItems.length; i++) {
            // IMPORTANT: Set display to 'flex' to activate the horizontal (image-left, text-right) layout
            projectItems[i].style.display = 'flex'; 
        }

        // 3. Update pagination text
        if (currentPageSpan) {
            currentPageSpan.textContent = String(currentPage).padStart(2, '0');
        }
        if (totalPagesSpan) {
            // Display the REQUESTED total slides (05)
            totalPagesSpan.textContent = String(REQUESTED_TOTAL_SLIDES).padStart(2, '0');
        }

        // 4. Update navigation button states
        if (prevButton) {
            prevButton.disabled = (currentPage === 1);
            prevButton.style.opacity = (currentPage === 1) ? 0.5 : 1;
        }
        if (nextButton) {
            // Disable when the current page equals the maximum content slide
            nextButton.disabled = (currentPage >= MAX_ACTIVE_SLIDES); 
            nextButton.style.opacity = (currentPage >= MAX_ACTIVE_SLIDES) ? 0.5 : 1;
        }
    }

    /**
     * Navigates to the next slide.
     */
    function goToNextSlide() {
        if (currentPage < MAX_ACTIVE_SLIDES) {
            currentPage++;
            updateProjects();
        }
    }

    /**
     * Navigates to the previous slide.
     */
    function goToPrevSlide() {
        if (currentPage > 1) {
            currentPage--;
            updateProjects();
        }
    }

    // --- Event Listeners for Pagination ---
    if (nextButton) {
        nextButton.addEventListener('click', goToNextSlide);
    }
    if (prevButton) {
        prevButton.addEventListener('click', goToPrevSlide);
    }

    // Initial load: display the first slide
    if (projectItems.length > 0) {
        updateProjects();
    }


    // --- Mobile Menu Toggle Logic ---
    const mobileMenuButton = document.getElementById('mobile-menu-toggle');
    const mainNav = document.getElementById('main-nav');
    
    if (mobileMenuButton && mainNav) {
        mobileMenuButton.addEventListener('click', () => {
            mainNav.classList.toggle('nav--open');
        });

        // Close menu when a link is clicked
        const navLinks = mainNav.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (mainNav.classList.contains('nav--open')) {
                    // Small delay to ensure the link click registers before closing the menu
                    setTimeout(() => {
                        mainNav.classList.remove('nav--open');
                    }, 50); 
                }
            });
        });
    }

});


