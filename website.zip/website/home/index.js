document.addEventListener('DOMContentLoaded', function () {

    // --- HERO SLIDER ---
    const slides = [
        {
            title: "PROJECT<br>NURTOWN",
            image: "../assets/hero.jpg"
        },
        {
            title: "MODERN<br>VILLA",
            image: "../assets/hero1.jpeg"
        },

    ];

    let currentSlide = 0;
    const heroTitle = document.getElementById('hero-title');
    const heroImage = document.getElementById('hero-image');
    const currentPageEl = document.getElementById('current-page');
    const totalPagesEl = document.getElementById('total-pages');
    const dotsContainer = document.getElementById('hero-dots-container');

    function updateSlide(index) {
        heroTitle.innerHTML = slides[index].title;
        heroImage.src = slides[index].image;
        currentPageEl.textContent = `0${index + 1}`;

        // Update dots
        document.querySelectorAll('.dot').forEach((dot, dotIndex) => {
            dot.classList.toggle('active', dotIndex === index);
        });
    }

    // Create dots
    totalPagesEl.textContent = `0${slides.length}`;
    slides.forEach((_, index) => {
        const dot = document.createElement('span');
        dot.classList.add('dot');
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => {
            currentSlide = index;
            updateSlide(currentSlide);
        });
        dotsContainer.appendChild(dot);
    });

    document.getElementById('next-slide').addEventListener('click', () => {
        currentSlide = (currentSlide + 1) % slides.length;
        updateSlide(currentSlide);
    });

    document.getElementById('prev-slide').addEventListener('click', () => {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        updateSlide(currentSlide);
    });

    // --- MOBILE MENU ---
    //const nav = document.getElementById('main-nav');
    //const menuToggle = document.getElementById('mobile-menu-toggle');
    //menuToggle.addEventListener('click', () => {
    //nav.classList.toggle('active');
});

// --- ACTIVE NAV LINK & SMOOTH SCROLL ---
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
    link.addEventListener('click', function (e) {
        // Smooth scroll for links with hash
        if (this.hash !== "") {
            e.preventDefault();
            const targetElement = document.querySelector(this.hash);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        }

        // Set active class
        navLinks.forEach(l => l.classList.remove('active'));
        this.classList.add('active');

        // Close mobile nav on click
        if (nav.classList.contains('active')) {
            nav.classList.remove('active');
        }
    });
});


// --- CONTACT FORM ---
const contactForm = document.getElementById('contact-form');
const successMessage = document.getElementById('form-success-message');
contactForm.addEventListener('submit', function (e) {
    e.preventDefault();
    successMessage.textContent = 'Спасибо! Ваша заявка успешно отправлена.';
    contactForm.reset();
    setTimeout(() => {
        successMessage.textContent = '';
    }, 5000); // Hide message after 5 seconds
});

    


        // --- Mobile Menu Toggle Script ---

document.addEventListener('DOMContentLoaded', () => {
    const mobileMenuButton = document.getElementById('mobile-menu-toggle');
    const mainNav = document.getElementById('main-nav');
    
    if (mobileMenuButton && mainNav) {
        mobileMenuButton.addEventListener('click', () => {
            // Toggle the 'nav--open' class on the navigation element
            mainNav.classList.toggle('nav--open');
            
            // Optional: You could also change the icon in the button 
            // by toggling a class on the button itself or changing the SVG path.
        });

        // Optional: Close the menu when a link is clicked (useful for single-page sites)
        const navLinks = mainNav.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                // Check if the menu is open before closing
                if (mainNav.classList.contains('nav--open')) {
                    mainNav.classList.remove('nav--open');
                }
            });
        });
    }
});