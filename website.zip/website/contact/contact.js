document.addEventListener('DOMContentLoaded', () => {
            const openModalBtn = document.getElementById('open-modal-btn');
            const closeModalBtn = document.getElementById('close-modal-btn');
            const modalOverlay = document.getElementById('modal-overlay');
            const modalForm = document.querySelector('.modal-form');
            const formContent = document.getElementById('modal-form-content');
            const successContent = document.getElementById('modal-success-content');
            const returnBtn = document.getElementById('return-btn');

            const openModal = () => {
                modalOverlay.classList.add('active');
            };

            const closeModal = () => {
                modalOverlay.classList.remove('active');
                
                // Reset modal to form view after a short delay to allow fade out
                setTimeout(() => {
                    successContent.style.display = 'none';
                    formContent.style.display = 'block';
                    modalForm.reset(); // Clear form fields
                }, 300);
            };

            openModalBtn.addEventListener('click', openModal);
            closeModalBtn.addEventListener('click', closeModal);
            returnBtn.addEventListener('click', closeModal);

            modalOverlay.addEventListener('click', (event) => {
                if (event.target === modalOverlay) {
                    closeModal();
                }
            });

            modalForm.addEventListener('submit', (event) => {
                event.preventDefault(); // Prevent actual form submission
                
                // Switch to success view
                formContent.style.display = 'none';
                successContent.style.display = 'block';
            });
        });
// --- Mobile Menu Toggle Script  ---

document.addEventListener('DOMContentLoaded', () => {
    // 1. Menu Toggle Logic
    const mobileMenuButton = document.getElementById('mobile-menu-toggle');
    const mainNav = document.getElementById('main-nav');
    
    if (mobileMenuButton && mainNav) {
        mobileMenuButton.addEventListener('click', () => {
            // Toggle the 'nav--open' class to show/hide the menu
            mainNav.classList.toggle('nav--open');
        });

        // Close menu when a link is clicked (improves mobile UX)
        const navLinks = mainNav.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (mainNav.classList.contains('nav--open')) {
                    // Small delay for smoother close animation
                    setTimeout(() => {
                        mainNav.classList.remove('nav--open');
                    }, 50); 
                }
            });
        });
    }

    // 2. Modal Logic (Assuming this is already or should be in contact.js)
    const openModalBtn = document.getElementById('open-modal-btn');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const returnBtn = document.getElementById('return-btn');
    const modalOverlay = document.getElementById('modal-overlay');
    const contactForm = document.querySelector('.modal-form');
    const formContent = document.getElementById('modal-form-content');
    const successContent = document.getElementById('modal-success-content');

    const closeModal = () => {
        modalOverlay.classList.remove('open');
        // Reset to form view when closing
        formContent.style.display = 'block';
        successContent.style.display = 'none';
        contactForm.reset();
    };

    if (openModalBtn && modalOverlay) {
        openModalBtn.addEventListener('click', () => {
            modalOverlay.classList.add('open');
        });

        closeModalBtn.addEventListener('click', closeModal);
        returnBtn.addEventListener('click', closeModal);

        // Close modal when clicking outside (on the overlay)
        modalOverlay.addEventListener('click', (e) => {
            if (e.target.id === 'modal-overlay') {
                closeModal();
            }
        });
        
        // Handle form submission
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Simulate form submission success
            formContent.style.display = 'none';
            successContent.style.display = 'block';
        });
    }
});